# SDET-test
## Challenge

NASA has an open API: https://api.nasa.gov/index.html#getting-started. It grants access to different features e.g: Astronomy Picture of the Day, Mars Rover Photos, etc.

We would like to test different scenarios that the API offers:
1. Retrieve the first 10 Mars photos made by "Curiosity" on 1000 Martian sol.
2. Retrieve the first 10 Mars photos made by "Curiosity" on Earth date equal to 1000 Martian sol.
3. Retrieve and compare the first 10 Mars photos made by "Curiosity" on 1000 sol and on Earth date equal to 1000 Martian sol.
4. Validate that the amounts of pictures that each "Curiosity" camera took on 1000 Mars sol is not greater than 10 times the amount taken by other cameras on the same date.

## Instructions
You will need to fork the repository and build the solution in Github **publicly**. Once you are finished, let HR know and share a link to your fork or a Zip file with your solution and the URL of the repository.

Implementation deadline is 1 week. Please let us know the time that you spent to achieve the task.


## Installation

- Install Nodejs -> https://nodejs.org/es/download/
- Install dependencies from npm install: You will be using cypress 6.2.0 version 


## Open Cypress Test Runner
To open the cypress test runner application runs `npx cypress open`


## Execute tests from command line
In order to execute the complete test suite only should do npx cypress run This line will run with electron browser, but some issues were detected using electron, so is better run with the following line that is a headless version of chrome `npx cypress run --browser chrome --headless`


